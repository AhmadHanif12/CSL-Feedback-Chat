from flask import Flask, render_template, request, redirect, url_for, flash,jsonify, session
from werkzeug.security import check_password_hash
from flask_login import login_user
from models import User, Feedback,Answer,db  # Adjust the import according to your project structure
from flask import Blueprint
from flask_login import current_user,LoginManager, logout_user, login_required

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
app.secret_key = 'your secret key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)


with app.app_context():
    db.create_all()

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route('/')
def index():
    return render_template('login.html')

@app.route('/submit-feedback', methods=['POST'])
def submit_feedback():
    # Access form data using request.form['input_name']
    feedback_type = request.form.get('feedback_type')
    challenge = request.form.get('challenge')  # This will be None if not set
    feedback_description = request.form.get('feedback_description')

    # You would then typically save this data to your database
    new_feedback = Feedback(feedback_type=feedback_type, challenge_name=challenge, description=feedback_description, user_id=current_user.id)
    db.session.add(new_feedback)
    db.session.commit()

    # Redirect or respond as necessary
    return redirect(url_for('mainpage'))

@login_required
@app.route('/mainpage')
def mainpage():
    all_feedbacks = Feedback.query.all()  # Or apply some filtering/ordering as needed
    all_answers = Answer.query.all()
    return render_template('mainpage.html', feedbacks=all_feedbacks,answers=all_answers)

@login_required
@app.route('/feedback')
def feedback():
    user = current_user
    return render_template('feedback.html',user=user)

@app.route('/admin')
def admin_dashboard():
    # if 'admin' not in session:  # Simple check to ensure user is admin
    #     return redirect(url_for('login'))

    feedbacks = Feedback.query.all()  # Retrieve all feedback items
    return render_template('admin.html', feedbacks=feedbacks)

@app.route('/submit-answer/<int:feedback_id>', methods=['POST'])
def submit_answer(feedback_id):
    if 'admin' not in session:
        return redirect(url_for('login'))

    answer_content = request.form.get('answer_content')
    new_answer = Answer(content=answer_content, feedback_id=feedback_id)  # Relate the new answer to the feedback
    db.session.add(new_answer)
    db.session.commit()
    return redirect(url_for('admin_dashboard'))

@app.route('/login',methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email).first()
        print(user)
        # Check if user actually exists and the password is correct
        # check_password_hash(user.password_hash, password)
        if not user or not user.check_password(password):
            flash('Please check your login details and try again.')
            return jsonify({'error': 'Invalid credentials'}), 401  # Unauthorized

        # If the above check passes, then we know the user has the right credentials
        login_user(user)
        return redirect(url_for('mainpage'))  # Redirect to the profile page, for example

    return render_template('login.html')  # Render the login template if GET


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
